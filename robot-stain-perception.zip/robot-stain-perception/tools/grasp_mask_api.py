import os
import cv2
import numpy as np
import sys
from datetime import datetime

# 将src目录添加到Python路径中，以便可以导入我们自己的API模块
# 注意：您可能需要根据您的项目结构调整此路径
try:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from src.perception_node.realsense_api import RealsenseAPI
    from src.perception_node.perception_api_detect import StainPerceptionAPI
except ImportError:
    print("警告：无法导入自定义的API模块。将使用虚拟API进行演示。")
    # 为了让代码能独立运行，这里定义虚拟类
    class RealsenseAPI:
        def get_frames(self):
            print("虚拟API：正在生成一张720x1280的黑色图像。")
            return np.zeros((720, 1280, 3), dtype=np.uint8), np.zeros((720, 1280), dtype=np.float32)
        def close(self):

            print("虚拟API：相机已关闭。")

    class StainPerceptionAPI:
        def __init__(self, model_path):
            print(f"虚拟API：使用模型 '{model_path}' 初始化。")
        def detect_stains(self, bgr_image, depth_image, conf_threshold):
            print(f"虚拟API：正在以置信度 {conf_threshold} 进行检测。")
            # --- 虚拟API修改 ---
            # 为了更好地演示，模拟同时检测到一个固体和一个液体污渍
            stains = []
            
            # 模拟一个固体污渍 (应该被保留)
            solid_mask = np.zeros(bgr_image.shape[:2], dtype=np.uint8)
            cv2.rectangle(solid_mask, (100, 100), (300, 300), 255, -1)
            stains.append({'mask': solid_mask, 'class_name': 'solid'})
            
            # 模拟一个液体污渍 (应该被忽略)
            liquid_mask = np.zeros(bgr_image.shape[:2], dtype=np.uint8)
            cv2.rectangle(liquid_mask, (450, 450), (600, 600), 255, -1)
            stains.append({'mask': liquid_mask, 'class_name': 'liquid'})
            
            return stains

def generate_and_save_grasp_mask(model_weights_path, output_path="/home/wmx/graspnet-baseline/mask.png", confidence_threshold=0.5):
    """
    按需启动相机，捕获图像，仅针对'solid'类别的污渍生成一张二值掩码图，
    并将其保存到指定路径。液体或其他类别的污渍将被忽略。

    Args:
        model_weights_path (str): 训练好的YOLOv8检测模型 (.pt) 文件路径。
        output_path (str, optional): 保存生成的掩码图的完整文件路径。
        confidence_threshold (float, optional): 检测的置信度阈值。

    Returns:
        str or None: 如果成功，返回保存的掩码文件的完整路径；否则返回None。
    """
    print("--- 按需生成并保存掩码图 (仅限 Solid) ---")

    realsense_api = None
    perception_api = None
    intrinsics=np.array(
    [   [608.20166016 ,  0.     ,    324.31015015],
        [  0.        , 608.04638672 ,243.1638031 ],
        [    0.      ,     0.      ,     1.        ]])

    try:
        perception_api = StainPerceptionAPI(model_weights_path)
        realsense_api = RealsenseAPI()

        print("📷 正在捕获稳定的图像帧...")
        bgr_image, depth_image_m = realsense_api.get_frames()

        if bgr_image is None:
            print("❌ 错误：无法从相机捕获图像。")
            return None
        print("✅ 图像捕获成功。")

        print("🚀 正在运行污渍检测...")
        detected_stains = perception_api.detect_stains(bgr_image, depth_image_m, confidence_threshold)

        # 5. 创建并合并掩码 (仅限solid)
        combined_mask = np.zeros(bgr_image.shape[:2], dtype=np.uint8)

        if not detected_stains:
            print("⚠️ 未检测到任何污渍。生成的掩码图将是全黑的。")
        else:
            # ✨✨✨ --- 主要修改点在这里 --- ✨✨✨
            print(f"🔍 检测到 {len(detected_stains)} 个总污渍，正在筛选并仅合并 'solid' 污渍的掩码...")
            solid_stains_found = 0
            
            # 遍历所有检测到的污渍
            for stain in detected_stains:
                # 检查污渍类别是否为 'solid'
                if stain.get('class_name') == 'solid':
                    # 如果是固体，则将其掩码合并到最终掩码中
                    combined_mask = cv2.bitwise_or(combined_mask, stain['mask'])
                    center_pixel = np.zeros((1, 2), dtype=int)
                    center_pixel = (stain['center_pixel'][0], stain['center_pixel'][1])
                    print(f"中心像素坐标",center_pixel)
                    
                    

                    # 像素对应深度值（单位: 米）
                    #Z = depth_image[v, u]   # 注意：v是y，u是x

                    # 构造像素齐次坐标
                    pix = np.array([stain['center_pixel'][0],  stain['center_pixel'][1], 1])

                    # 计算相机坐标
                    K_inv = np.linalg.inv(intrinsics)
                    cam = (K_inv @ pix)

                    X, Y, Z = cam
                    print(f"Camera coordinates: X={X:.4f} m, Y={Y:.4f} m, Z={Z:.4f} m")
                 
                    solid_stains_found += 1
                    completed_grasp =False
            
            if solid_stains_found > 0:
                print(f"✅ 成功合并 {solid_stains_found} 个 'solid' 污渍的掩码。")
            else:
                print("⚠️ 在检测到的污渍中没有发现 'solid' 类别的污渍，掩码图将是全黑的。")
                completed_grasp =True
            # ✨✨✨ --- 修改结束 --- ✨✨✨

        # 6. 保存最终的掩码图
        output_dir = os.path.dirname(output_path)
        if output_dir:
             os.makedirs(output_dir, exist_ok=True)

        print(f"💾 正在保存掩码图至: '{output_path}'")
        cv2.imwrite(output_path, combined_mask)
        print("✅ 保存成功！")

        return output_path , completed_grasp

    except Exception as e:
        print(f"❌ 发生了严重错误: {e}")
        return None

    finally:
        if realsense_api:
            realsense_api.close()
        print("--- 脚本执行完毕 ---")


if __name__ == "__main__":
    from PIL import Image

    # --- 配置参数 ---
    YOLO_MODEL_PATH = "/home/wmx/graspnet-baseline/robot-stain-perception/weights/best.pt"
    OUTPUT_MASK_PATH = "/home/wmx/graspnet-baseline/mask.png"
    CONF_THRESHOLD = 0.5

    # --- 执行主函数 ---
    saved_mask_path ,completed_grasp= generate_and_save_grasp_mask(
        model_weights_path=YOLO_MODEL_PATH,
        output_path=OUTPUT_MASK_PATH,
        confidence_threshold=CONF_THRESHOLD
    )

    # --- 处理返回的路径 ---
    if saved_mask_path:
        print(f"\n✅ 掩码已成功生成并保存到: {saved_mask_path}")
        print("现在模拟您的原始调用流程...")
        try:
            workspace_mask = np.array(Image.open(saved_mask_path).resize((640, 480), Image.NEAREST))
            print(f"成功读取并调整掩码尺寸为: {workspace_mask.shape}")
            # 在这里可以继续使用 workspace_mask
            
            # (可选) 显示最终生成的掩码图来验证结果
            cv2.imshow("Generated Solid-Only Mask", workspace_mask)
            print("按任意键退出显示...")
            cv2.waitKey(0)
            cv2.destroyAllWindows()

        except FileNotFoundError:
            print(f"❌ 错误: 找不到文件 {saved_mask_path}")
        except Exception as e:
            print(f"❌ 读取或处理图像时出错: {e}")
    else:
        print("\n❌ 生成掩码文件失败。")