# perception_api_detect.py

import os
import cv2
import numpy as np
from ultralytics import YOLO

class StainPerceptionAPI:
    """
    一个专为机器人清洁任务设计的感知API。
    它使用一个YOLOv8 *检测* 模型来识别污渍区域（矩形框），
    并输出矩形掩码及该区域内的深度信息。
    """

    def __init__(self, model_weights_path):
        """
        通过加载YOLOv8 *检测* 模型来初始化API。

        Args:
            model_weights_path (str): 训练好的 .pt 模型文件路径。
        """
        if not os.path.exists(model_weights_path):
            raise FileNotFoundError(f"Model weights not found at: {model_weights_path}")
        
        print(f"🧠 Loading YOLO detector from '{model_weights_path}'...")
        self.model = YOLO(model_weights_path)
        print("✅ StainPerceptionAPI (Detection-Based) initialized successfully.")

    def detect_stains(self, rgb_image, depth_image, confidence_threshold=0.5):
        """
        (Step 1 API) 在RGB图像中检测所有污渍，并提取它们的矩形掩码和深度信息。

        Args:
            rgb_image (np.ndarray): BGR格式的输入彩色图像。
            depth_image (np.ndarray): 已对齐的深度图像，单位为米。
            confidence_threshold (float): 检测的置信度阈值。

        Returns:
            list[dict]: 检测到的污渍列表。
        """
        results = self.model.predict(source=rgb_image, conf=confidence_threshold, verbose=False)
        result = results[0]
        detected_stains = []

        if len(result.boxes) == 0: return detected_stains

        for box in result.boxes:
            class_id = int(box.cls[0])
            class_name = self.model.names[class_id]
            confidence = float(box.conf[0])
            bbox = box.xyxy[0].cpu().numpy().astype(int)
            x1, y1, x2, y2 = bbox
            x_center, y_center = (x1 + x2) // 2, (y1 + y2) // 2

            mask = np.zeros(rgb_image.shape[:2], dtype=np.uint8)
            cv2.rectangle(mask, (x1, y1), (x2, y2), 255, -1)

            depth_roi = depth_image[y1:y2, x1:x2]
            valid_depth_values = depth_roi[depth_roi > 0]
            
            depth_info = None
            if valid_depth_values.size > 0:
                depth_info = {
                    "median_m": round(float(np.median(valid_depth_values)), 3),
                    "mean_m": round(float(np.mean(valid_depth_values)), 3),
                }
            
            detected_stains.append({
                "class_name": class_name,
                "confidence": confidence,
                "bbox": bbox.tolist(),
                "mask": mask,
                "depth_info": depth_info,
                "center_pixel": (int(x_center), int(y_center))
            })

        return detected_stains

    # ###########################################################
    # ## 更新后的 'verify_cleanliness' 方法
    # ###########################################################
    def verify_cleanliness(self, rgb_image, area_of_interest=None, confidence_threshold=0.5, target_class='all'):
        """
        (Step 2 API) 检查给定区域是否干净，可以指定目标类别。

        Args:
            rgb_image (np.ndarray): BGR格式的输入彩色图像。
            area_of_interest (tuple, optional): (x1, y1, x2, y2) 格式的待检查区域。
            confidence_threshold (float): 检测的最低置信度。
            target_class (str, optional): 要检查的目标类别 ('liquid', 'solid', 或 'all'). 
                                          默认为 'all'。

        Returns:
            dict: 包含'is_clean' (bool) 和 'remaining_stains' (list) 的字典。
        """
        image_to_check = rgb_image
        if area_of_interest:
            x1, y1, x2, y2 = map(int, area_of_interest)
            image_to_check = rgb_image[y1:y2, x1:x2]

        # 运行一次完整的检测
        results = self.model.predict(source=image_to_check, conf=confidence_threshold, verbose=False)
        
        remaining_stains = []
        if len(results[0].boxes) > 0:
            # 遍历所有检测结果
            for box in results[0].boxes:
                class_name = self.model.names[int(box.cls[0])]
                
                # 如果目标是'all'或者当前检测的类别与目标类别匹配，则记录为剩余污渍
                if target_class == 'all' or class_name == target_class:
                    remaining_stains.append({
                        "class_name": class_name,
                        "confidence": float(box.conf[0]),
                        "bbox": box.xyxy[0].cpu().numpy().astype(int).tolist()
                    })
        
        # 判断标准：过滤后的剩余污渍列表是否为空
        is_clean = len(remaining_stains) == 0
        
        return {
            "is_clean": is_clean,
            "remaining_stains": remaining_stains
        }
    # ###########################################################
    # ## 方法更新结束
    # ###########################################################